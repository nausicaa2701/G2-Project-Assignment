# Reproducibility

All results in `results/`, all figures in `figures/` and every number shown by the web application are produced by
`WDI_Analysis.ipynb` from the raw Kaggle files. This document lists the environment, the data, the steps and what
each step writes.

## 1. Environment

| Item | Value |
|---|---|
| Python | 3.11 or later (tested with 3.14.0) |
| Operating system | tested on macOS 26 (Apple silicon); any system with Python, `make`, `curl` and `unzip` |
| Packages | `requirements.txt` (exact versions) |
| Disk | about 1.5 GB (raw data and virtual environment) |

```bash
make setup                                 # python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
make setup PYTHON=/path/to/python3.12      # with another interpreter
```

## 2. Data

World Bank, *World Development Indicators*, Kaggle release
<https://www.kaggle.com/datasets/kaggle/world-development-indicators> (public, no account needed).

```bash
make data       # downloads the archive (about 390 MB) and extracts three files into data/raw/
```

The first code cell of the notebook performs the same download when `data/raw/` is empty.

| File | Size | MD5 (from the archive's `hashes.txt`) |
|---|---|---|
| `Country.csv` | 0.13 MB | `a1599359a698cfbb6d06e351e7a4af98` |
| `Series.csv` | 3.3 MB | `fe37c2c941fd6fd1123965f1223dd969` |
| `Indicators.csv` | 574 MB | `3c8e84290727077b2ba4665d4081b913` |

Check with `md5 data/raw/*.csv` (macOS) or `md5sum data/raw/*.csv` (Linux).

## 3. Steps

```bash
make all        # setup + data + notebook + test
make app        # web application at http://localhost:8501
```

| Step | Command | Writes | Time* |
|---|---|---|---|
| Environment | `make setup` | `.venv/` | under 1 min with cached packages |
| Data | `make data` | `data/raw/` | depends on the connection |
| Notebook, §1–8: ETL and analysis | `make notebook` | `data/processed/`, `figures/01–21_*.png` | about 1.5 min |
| Notebook, §9: model suite | (same run) | `results/metrics_*`, `summary_*`, `importance_*`, `trends_*`, `figures/22_model_suite.png` | about 36 min (snapshot 7 min, panel 29 min) |
| Notebook, §10: experiments | (same run) | `results/story/`, `figures/story/` | under 1 min |
| Tests | `make test` | pass / fail | under 1 min |
| Web application | `make app` | – | – |

\* Measured on the test machine (Apple silicon laptop); `make all` took 37.5 min in total with the data already downloaded.

`make notebook` runs `jupyter nbconvert --execute --inplace WDI_Analysis.ipynb`; opening the notebook in Jupyter or
VS Code and running all cells gives the same result. Sections 9 and 10 can also be run from the command line:

```bash
.venv/bin/python run_models.py --mode snapshot --seeds 0 1 2 3 4    # section 9
.venv/bin/python run_models.py --mode panel --seeds 0 1 2
.venv/bin/python -m wdi.story                                       # section 10
.venv/bin/python run_story.py --part 2
```

Without `make` (for example on Windows), run the commands of the `Makefile` one by one, replacing `.venv/bin/` by
`.venv\Scripts\`.

## 4. Determinism

- Every random procedure has a fixed seed: models use seeds 0–4 (snapshot) and 0–2 (panel); clustering uses seed 42
  for the reference partition and seeds 0–19 for the robustness experiment.
- Cross-validation folds are grouped by country, and imputation and scaling are fitted inside each training fold.
- Re-running the full pipeline on a clean copy reproduces `data/processed/` and every file in `results/story/`
  exactly. In the model suite, the best model of every theme and its mean R² are unchanged to within 0.001;
  boosting models (XGBoost, AdaBoost, gradient boosting) can differ by up to 0.02 in R² for an individual seed
  across library versions and thread counts.

## 5. Web application inputs

The application reads `data/processed/` when it exists (after `make notebook`) and otherwise the compressed copies
in `app_data/`; precomputed results come from `results/`. Model and clustering settings in the Lab tabs are
recomputed live.

## 6. Tests

`make test` checks the pipeline against the headline numbers, for example: no duplicate keys and 29 hyperinflation
years in the processed panel; 69 countries left under listwise deletion; PC1 = 63.5 % of the variance; 74 % agreement
between clusters and income groups; a within-country income slope smaller than the between-country slope. It also
renders every page and tab of the web application in light and dark mode.
