# Does richer mean more developed?

A data-mining study of the World Bank World Development Indicators (WDI), 1960–2014.

**Group G2** · Le Thi Hong Cuc (2470882) · Phan Van Nguyen Khanh (2470883) · Nguyen Tuong Phuc (2470886)
**Lecturer** · Dr. Nguyen Thi Ai Thao · Faculty of Computer Science and Engineering, Ho Chi Minh City University of Technology

## TL;DR

- **Mostly yes.** Log GDP per capita alone explains 55–81 % of the cross-country differences in health, education,
  demography, environment and technology (mean 67 %); the best of 19 machine-learning models reaches 82 %.
- **Health converged, income did not.** The spread of life expectancy between countries fell by about half since
  1960, while the spread of income did not change.
- **Being rich matters more than getting rich.** Ten times more income goes with about +11 years of life between
  countries, but only about +3 years within a country over time.
- **Income groups are a rough guide.** Data-driven clusters match the World Bank income groups for 74 % of
  countries; development behaves like a continuum.
- **Vietnam** lives about 10 years longer than its income predicts, the largest gap of all countries, but emits
  3.2 times the CO₂ its income predicts.

## Quick start

Requires Python 3.11 or later and `make`.

```bash
make app        # create .venv, install requirements.txt, open the web application at http://localhost:8501
make all        # reproduce every result from the raw data (see REPRODUCIBILITY.md)
```

The web application runs immediately on the processed tables in `app_data/` and the results in `results/`.
`make all` regenerates both from the raw Kaggle files.

## Contents

| Path | Content |
|---|---|
| `WDI_Analysis.ipynb` | end-to-end notebook: download, ETL, missing-data audit, exploratory analysis, trends, comparisons, evaluation, model suite, experiments |
| `app.py`, `ui/` | Streamlit web application |
| `wdi/models.py` | suite of 19 regressors with country-grouped cross-validation |
| `wdi/story/` | data checks (A, B) and experiments E1.1–E3.3 |
| `run_models.py`, `run_story.py` | command-line versions of notebook sections 9 and 10 |
| `app_data/` | compressed processed tables (panel 11,935 × 32, snapshot 214 × 32) |
| `results/` | model and experiment results (CSV) |
| `figures/` | charts written by the notebook |
| `tests/` | automated tests |
| `Makefile` | one target per step |

## Web application

| Page | Content |
|---|---|
| Home | title, group, TL;DR, key numbers |
| Data | A · Exploration (dataset overview, summary statistics, missing values, outliers, groups) · B · Preprocessing (cleaning, integration, transformation, reduction) |
| Findings | 1 · What changed (convergence) · 2 · Why (role of income) · 3 · So what (clusters, Vietnam) |
| Lab | Trends · Compare · Models · Clusters, recomputed live |

Each tab has its own address, for example `http://localhost:8501/findings?tab=why`.

## Data

World Bank, *World Development Indicators*, Kaggle release
<https://www.kaggle.com/datasets/kaggle/world-development-indicators>. The notebook (or `make data`) downloads the
three files used, `Country.csv`, `Series.csv` and `Indicators.csv`, into `data/raw/`.
